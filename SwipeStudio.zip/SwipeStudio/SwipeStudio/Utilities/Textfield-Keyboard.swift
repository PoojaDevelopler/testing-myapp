//
//  Textfield-Keyboard.swift
//  SwipeStudio
//
//  Created by Pooja Negi on 29/07/18.
//  Copyright © 2018 PNKBKSH. All rights reserved.
//

import Foundation

import UIKit

//Mark-for key pad
extension UITextField {
    
    @IBInspectable var nextButton: Bool{
        get{return self.nextButton}
        set (isNext) {
            if isNext{nextButtonOnKeyboard()}
        }
    }
    
    @IBInspectable var doneButton: Bool{
        get{
            return self.doneButton
        }
        set (isDone) {
            if isDone{
                doneButtonOnKeyboard()
            }
        }
    }
    
    func nextButtonOnKeyboard() {
        
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        doneToolbar.barStyle = .default
        
        let cancel: UIBarButtonItem = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelButtonAction))
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem = UIBarButtonItem(title: "Next", style: .done, target: self, action: #selector(self.nextButtonAction))
        
        let items = [cancel , flexSpace, done]
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        self.inputAccessoryView = doneToolbar
    }
    
    func doneButtonOnKeyboard() {
        
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        doneToolbar.barStyle = .default
        
        let cancel: UIBarButtonItem = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelButtonAction))
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.doneButtonAction))
        
        let items = [cancel , flexSpace, done]
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        self.inputAccessoryView = doneToolbar
    }
    
    @objc func doneButtonAction() {self.resignFirstResponder()}
    
    @objc func cancelButtonAction() {
        self.text = ""
        self.resignFirstResponder()
    }
    
    @objc func nextButtonAction(){
        guard let nextField = self.superview?.viewWithTag(self.tag + 1) as? UITextField else{
            self.resignFirstResponder()
            return
        }
        nextField.becomeFirstResponder()
    }
}

