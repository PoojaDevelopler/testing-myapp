//
//  Extension.swift
//  SwipeStudio
//
//  Created by Pooja Negi on 29/07/18.
//  Copyright © 2018 PNKBKSH. All rights reserved.
//

import UIKit

extension UIView{
    
    //Roate view 360 degree
    func rotate360Degrees(duration: CFTimeInterval = 1.5, completionDelegate: AnyObject? = nil) {
        
        let rotateAnimation         = CABasicAnimation(keyPath: "transform.rotation")
        rotateAnimation.fromValue   = 0.0
        rotateAnimation.toValue     = CGFloat(Double.pi * 2.0)
        rotateAnimation.duration    = duration
        rotateAnimation.repeatCount = Float.infinity
        
        DispatchQueue.main.async(execute: {
            if let delegate: AnyObject = completionDelegate {
                rotateAnimation.delegate = delegate as? CAAnimationDelegate
            }
            self.layer.add(rotateAnimation, forKey: nil)
        })
    }
}

extension UIViewController{
    // MARK: Alerts view
    func showAlert(title: String?, message: String?, buttonTitle: String?){
        let alertVC     = UIAlertController(title: title != nil ? title! : nil, message: message != nil ? message! : nil, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: buttonTitle != nil ? buttonTitle : "Ok", style: UIAlertActionStyle.default, handler: nil))
        self.present(alertVC, animated: true, completion: nil)
    }
    
    func presentFadeAnimation(_ viewControllerToPresent: UIViewController){
        
        let transition = CATransition()
        transition.duration = 0.5
        transition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition.type = kCATransitionFade
        transition.subtype = kCATransitionFromRight
        navigationController?.view.layer.add(transition, forKey: kCATransition)
        navigationController?.pushViewController(viewControllerToPresent, animated: false)
    }
    
    func dissmissFadeView(){
        let transition = CATransition()
        transition.duration = 0.45
        transition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition.type = kCATransitionFade
        transition.subtype = kCATransitionFromRight
        navigationController?.view.layer.add(transition, forKey: kCATransition)
        navigationController?.popViewController(animated: true)
    }
}

extension UIColor{
    
    /**
     Returns the UIColor with the hex code provided
     - returns: UIColor
     - parameter String
     - Throws: nil
     */
    class func colorWithHex(_ colorHexCode:String) -> UIColor{
        
        //        var cString: String = colorHexCode.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet()).uppercased()
        
        
        var cString = colorHexCode.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).uppercased()
        
        cString = cString.replacingOccurrences(of: "#", with: "")
        if cString.count < 6 {
            //Return Default Color
            return UIColor.gray
        }
        if cString.hasPrefix("0X") {
            cString = (cString as NSString).substring(from: 2)
        }
        if cString.count != 6 {
            //Return Default Color
            return UIColor.gray
        }
        var range: NSRange = NSRange()
        range.location = 0
        range.length = 2
        let rString: String = (cString as NSString).substring(with: range)
        range.location = 2
        let gString: String = (cString as NSString).substring(with: range)
        range.location = 4
        let bString: String = (cString as NSString).substring(with: range)
        var r: UInt32 = 0
        var g: UInt32 = 0
        var b: UInt32 = 0
        
        Scanner(string: rString).scanHexInt32(&r)
        Scanner(string: gString).scanHexInt32(&g)
        Scanner(string: bString).scanHexInt32(&b)
        
        return UIColor(red: (CGFloat(r)/255.0), green: (CGFloat(g)/255.0), blue: (CGFloat(b)/255.0), alpha: 1.0)
    }
}
