//
//  LoginVC.swift
//  SwipeStudio
//
//  Created by Pooja Negi on 29/07/18.
//  Copyright © 2018 PNKBKSH. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}


//MARK:- TextField Delegate
extension LoginVC{
    
        func login_To_APP(){
        activityIndicator.show(animated: true)
        
        HttpClientApi.instance().makeAPICall(url: PINGAPI.logintoApp, params: nil, header: nil, method: .POST, success: { (data, response, error) in
            
            do{
                if let data = data , let json = try JSONSerialization.jsonObject(with: data) as? NSDictionary{
                    if let status = json.value(forKey: "statusCode") as? Int , status == 200 {
                        DispatchQueue.main.async {

                        }
                    }
                    else {
                        activityIndicator.didTappedOnBackgroundView()
                        self.showAlert(title: "Error", message: json.value(forKey: "message") as? String , buttonTitle: "OK")
                    }
                }
            }
            catch{
                DispatchQueue.main.async (execute:{
                    activityIndicator.didTappedOnBackgroundView()
                    self.showAlert(title: "Error", message: "Something went wrong", buttonTitle: "OK")
                })
            }
            
        }, failure:{ (data, response , error) in
            activityIndicator.didTappedOnBackgroundView()
            self.showAlert(title:"Error", message:"Server not responding", buttonTitle: "OK")
            
        })
    }
    
}
