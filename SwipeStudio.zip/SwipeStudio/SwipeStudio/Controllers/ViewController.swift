//
//  ViewController.swift
//  SwipeStudio
//
//  Created by Pooja Negi on 28/07/18.
//  Copyright © 2018 PNKBKSH. All rights reserved.
//

import UIKit
import SCSDKLoginKit
import SCSDKCreativeKit

class ViewController: UIViewController , SCSDKLoginButtonDelegate{
   
//,
    let loginButton = SCSDKLoginButton()
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loginButton.delegate = self
        loginButton.frame = CGRect(x: 20, y: (self.view.frame.maxY - 100), width: self.view.frame.size.width - 40, height: 50)
        self.view.addSubview(loginButton)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    func loginButtonDidTap() {
        print("code done")
        let graphyQLQuery = "{me{displayName, bitmoji{avatar}, externalId}}"
        let variables = ["page": "bitmoji"]
        SCSDKLoginClient.fetchUserData(withQuery: graphyQLQuery, variables: variables, success: { resources in
            var data = resources?["data"] as? [AnyHashable : Any]
            
            var me = data?["me"] as? [AnyHashable : Any]
            let displayName = me?["displayName"] as? String
            
            var bitmoji = me?["bitmoji"] as? [AnyHashable : Any]
            let bitmojiAvatarUrl = bitmoji?["avatar"] as? String
            
            
            print(displayName ?? "hehheh")
            print(bitmojiAvatarUrl ?? "no url")
            
        }, failure: { error, isUserLoggedOut in
            // handle error as appropriate
        })

    }
    
    
   @IBAction func loginButton(_sender:UIButton) {
        SCSDKLoginClient.login(from: self) { success, error in
            
                if let error = error {
                    // An error occurred during the login process
                    print(error.localizedDescription)
                } else {
                    // The login was a success! This user is now
                    // authenticated with Snapchat!
                    // swift
                    
                    let graphyQLQuery = "{me{displayName, bitmoji{avatar}, externalId}}"
                    let variables = ["page": "bitmoji"]
                    SCSDKLoginClient.fetchUserData(withQuery: graphyQLQuery, variables: variables, success: { resources in
                        var data = resources?["data"] as? [AnyHashable : Any]
                        
                        var me = data?["me"] as? [AnyHashable : Any]
                        let displayName = me?["displayName"] as? String
                        
                        var bitmoji = me?["bitmoji"] as? [AnyHashable : Any]
                        let bitmojiAvatarUrl = bitmoji?["avatar"] as? String
                        
                        
                        print(displayName ?? "hehheh")
                        print(bitmojiAvatarUrl ?? "no url")
                        
                    }, failure: { error, isUserLoggedOut in
                        // handle error as appropriate
                    })

                    
                }
            }
    }
    
}

