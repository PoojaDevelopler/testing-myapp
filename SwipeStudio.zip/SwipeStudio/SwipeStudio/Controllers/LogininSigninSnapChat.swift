//
//  LogininSigninSnapChat.swift
//  SwipeStudio
//
//  Created by Pooja Negi on 30/07/18.
//  Copyright © 2018 PNKBKSH. All rights reserved.
//

import UIKit

class LogininSigninSnapChat: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    @IBAction func login( _ sender:UIButton ){
    
    }

}
