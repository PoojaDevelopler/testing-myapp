//
//  Constant.swift
//  SwipeStudio
//
//  Created by Pooja Negi on 29/07/18.
//  Copyright © 2018 PNKBKSH. All rights reserved.
//


import Foundation
import UIKit


let activityIndicator  = CustomAlert(title: "", image: #imageLiteral(resourceName: "GearLoader-1"))
let mainSB  = UIStoryboard.init(name: "Main", bundle: nil)
