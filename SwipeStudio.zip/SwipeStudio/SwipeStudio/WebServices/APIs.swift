//
//  APIs.swift
//  SwipeStudio
//
//  Created by Pooja Negi on 28/07/18.
//  Copyright © 2018 PNKBKSH. All rights reserved.
//

import Foundation

struct PINGAPI {
    
    static var baseURL = ""
    static var logintoApp = baseURL + ""
   
}
