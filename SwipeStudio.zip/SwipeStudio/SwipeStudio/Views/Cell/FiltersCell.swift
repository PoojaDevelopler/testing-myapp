//
//  FiltersCell.swift
//  SwipeStudio
//
//  Created by Pooja Negi on 30/07/18.
//  Copyright © 2018 PNKBKSH. All rights reserved.
//

import UIKit

class FiltersCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
